import { Header } from "@/components/brume/header"
import { LocationChip } from "@/components/brume/location-chip"
import { MapArea } from "@/components/brume/map-area"
import { BottomSheet } from "@/components/brume/bottom-sheet"
import { SosButton } from "@/components/brume/sos-button"
import { BottomNav } from "@/components/brume/bottom-nav"

export default function Page() {
  return (
    <main className="relative mx-auto h-dvh overflow-hidden bg-background" style={{ maxWidth: 390 }}>
      <Header />
      <LocationChip />

      {/* Map fills remaining space */}
      <div className="h-full pt-16">
        <MapArea />
      </div>

      <BottomSheet />
      <SosButton />
      <BottomNav />
    </main>
  )
}
