"use client"

import { Search, Bell } from "lucide-react"

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between bg-card px-4 shadow-sm" style={{ height: 64 }}>
      <h1 className="text-xl font-semibold tracking-tight text-foreground">
        Brume
      </h1>
      <div className="flex items-center gap-2">
        <button
          className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-foreground transition-colors hover:bg-muted"
          aria-label="Rechercher"
        >
          <Search className="h-[18px] w-[18px]" />
        </button>
        <button
          className="relative flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-foreground transition-colors hover:bg-muted"
          aria-label="Notifications"
        >
          <Bell className="h-[18px] w-[18px]" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[var(--color-danger)]" />
        </button>
      </div>
    </header>
  )
}
