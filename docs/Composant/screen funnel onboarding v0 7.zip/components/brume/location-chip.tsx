"use client"

export function LocationChip() {
  return (
    <div className="fixed left-1/2 z-40 -translate-x-1/2" style={{ top: 76 }}>
      <div
        className="flex items-center gap-2 rounded-full bg-card px-4 shadow-md"
        style={{ height: 36 }}
      >
        <span className="h-2 w-2 rounded-full bg-[var(--color-gold)]" />
        <span className="text-sm font-medium text-foreground">
          {"15\u00e8me arrondissement"}
        </span>
        <span className="text-sm text-muted-foreground">{"·"}</span>
        <span className="text-sm font-medium text-[var(--color-danger)]">
          3 incidents
        </span>
      </div>
    </div>
  )
}
