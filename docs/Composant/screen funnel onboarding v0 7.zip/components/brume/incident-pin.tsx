"use client"

import type { ReactNode } from "react"

interface IncidentPinProps {
  icon: ReactNode
  label: string
  type: "harassment" | "assault" | "theft"
  style?: React.CSSProperties
}

const borderColors: Record<IncidentPinProps["type"], string> = {
  harassment: "var(--color-amber)",
  assault: "var(--color-danger)",
  theft: "var(--color-gold)",
}

export function IncidentPin({ icon, label, type, style }: IncidentPinProps) {
  return (
    <div className="absolute flex flex-col items-center gap-1" style={style}>
      <div
        className="flex h-8 w-8 items-center justify-center rounded-full bg-card shadow-md"
        style={{ borderLeft: `3px solid ${borderColors[type]}` }}
      >
        <span className="text-sm">{icon}</span>
      </div>
      <span className="whitespace-nowrap rounded-full bg-card px-2 py-0.5 text-[10px] font-medium text-foreground shadow-sm">
        {label}
      </span>
    </div>
  )
}
