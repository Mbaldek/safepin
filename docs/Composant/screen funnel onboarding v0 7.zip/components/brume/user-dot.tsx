"use client"

interface UserDotProps {
  style?: React.CSSProperties
}

export function UserDot({ style }: UserDotProps) {
  return (
    <div className="absolute" style={style}>
      <div className="relative flex items-center justify-center">
        {/* Outer pulse ring */}
        <div className="absolute h-9 w-9 rounded-full bg-[var(--color-gold)]/20 animate-pulse-gold" />
        {/* Main dot */}
        <div
          className="relative rounded-full bg-[var(--color-gold)]"
          style={{
            width: 18,
            height: 18,
            border: "3px solid white",
            boxShadow: "0 2px 8px rgba(212, 168, 83, 0.4)",
          }}
        />
      </div>
    </div>
  )
}
