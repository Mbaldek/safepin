"use client"

import { useState } from "react"

export function SosButton() {
  const [pressed, setPressed] = useState(false)

  return (
    <button
      className="fixed z-50 flex items-center justify-center rounded-full bg-primary text-primary-foreground animate-sos-glow transition-transform active:scale-95"
      style={{
        width: 56,
        height: 56,
        bottom: 88,
        right: 20,
      }}
      onClick={() => setPressed(!pressed)}
      aria-label="SOS - Appel d'urgence"
    >
      <span className="text-sm font-bold tracking-wide">SOS</span>
    </button>
  )
}
