"use client"

import { useState } from "react"
import { AlertTriangle, ShieldAlert, Eye } from "lucide-react"

interface Incident {
  icon: ReactNode
  label: string
  description: string
  distance: string
  time: string
  borderColor: string
}

import type { ReactNode } from "react"

const incidents: Incident[] = [
  {
    icon: <AlertTriangle className="h-4 w-4 text-[var(--color-amber)]" />,
    label: "Harcelement",
    description: "Harcelement verbal signale pres du metro",
    distance: "120m",
    time: "Il y a 15 min",
    borderColor: "var(--color-amber)",
  },
  {
    icon: <ShieldAlert className="h-4 w-4 text-[var(--color-danger)]" />,
    label: "Agression",
    description: "Tentative de vol a l'arret de bus",
    distance: "280m",
    time: "Il y a 45 min",
    borderColor: "var(--color-danger)",
  },
  {
    icon: <Eye className="h-4 w-4 text-[var(--color-gold)]" />,
    label: "Comportement suspect",
    description: "Individu suspect pres du parc",
    distance: "350m",
    time: "Il y a 1h",
    borderColor: "var(--color-gold)",
  },
]

export function BottomSheet() {
  const [expanded, setExpanded] = useState(false)

  return (
    <div
      className="fixed bottom-16 left-0 right-0 z-40 bg-card transition-all duration-300 ease-in-out"
      style={{
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        boxShadow: "0 -4px 24px rgba(0,0,0,0.08)",
        maxHeight: expanded ? "60vh" : 160,
      }}
    >
      {/* Drag Handle */}
      <button
        className="flex w-full cursor-grab items-center justify-center pb-2 pt-3"
        onClick={() => setExpanded(!expanded)}
        aria-label={expanded ? "Reduire" : "Agrandir"}
      >
        <div className="h-1 w-10 rounded-full bg-muted" />
      </button>

      {/* Title */}
      <div className="px-5 pb-3">
        <h2 className="text-base font-semibold text-foreground">
          {"3 incidents a proximite"}
        </h2>
      </div>

      {/* Incident List */}
      <div className="overflow-y-auto px-5 pb-4" style={{ maxHeight: expanded ? "calc(60vh - 80px)" : 70 }}>
        <div className="flex flex-col gap-3">
          {incidents.map((incident, i) => (
            <div
              key={i}
              className="flex items-center gap-3 rounded-xl bg-secondary/50 p-3 transition-colors hover:bg-secondary"
              style={{ borderLeft: `3px solid ${incident.borderColor}` }}
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-card">
                {incident.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-foreground truncate">
                    {incident.description}
                  </p>
                </div>
                <div className="mt-0.5 flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{incident.time}</span>
                  <span className="text-xs text-muted-foreground">{"·"}</span>
                  <span className="text-xs font-medium text-[var(--color-gold)]">{incident.distance}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
