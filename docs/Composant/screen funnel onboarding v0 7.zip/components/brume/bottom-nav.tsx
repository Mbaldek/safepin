"use client"

import { useState } from "react"
import { Map, Users, Route, User } from "lucide-react"
import type { ReactNode } from "react"

interface NavItem {
  id: string
  label: string
  icon: ReactNode
}

const navItems: NavItem[] = [
  { id: "carte", label: "Carte", icon: <Map className="h-5 w-5" /> },
  { id: "communaute", label: "Communaute", icon: <Users className="h-5 w-5" /> },
  { id: "trajet", label: "Trajet", icon: <Route className="h-5 w-5" /> },
  { id: "moi", label: "Moi", icon: <User className="h-5 w-5" /> },
]

export function BottomNav() {
  const [active, setActive] = useState("carte")

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around border-t border-border bg-card"
      style={{ height: 64, paddingBottom: "env(safe-area-inset-bottom)" }}
      aria-label="Navigation principale"
    >
      {navItems.map((item) => {
        const isActive = item.id === active
        return (
          <button
            key={item.id}
            className="flex flex-1 flex-col items-center gap-0.5 pt-2 pb-1 transition-colors"
            onClick={() => setActive(item.id)}
            aria-current={isActive ? "page" : undefined}
          >
            <span className={isActive ? "text-foreground" : "text-muted-foreground"}>
              {item.icon}
            </span>
            <span
              className={`text-[11px] font-medium ${
                isActive ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              {item.label}
            </span>
            {isActive && (
              <span className="mt-0.5 h-1 w-1 rounded-full bg-[var(--color-gold)]" />
            )}
          </button>
        )
      })}
    </nav>
  )
}
