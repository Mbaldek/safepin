"use client"

import { IncidentPin } from "./incident-pin"
import { UserDot } from "./user-dot"
import { AlertTriangle, ShieldAlert, Eye } from "lucide-react"

export function MapArea() {
  return (
    <div className="relative h-full w-full overflow-hidden bg-background">
      {/* Stylized map background */}
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 390 844"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden="true"
      >
        {/* Base grid — subtle street lines */}
        <defs>
          <pattern id="streets" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M0 30 H60" stroke="#E0D9D1" strokeWidth="1.5" />
            <path d="M30 0 V60" stroke="#E0D9D1" strokeWidth="1.5" />
          </pattern>
          <pattern id="smallGrid" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M0 10 H20" stroke="#E8E2DB" strokeWidth="0.5" />
            <path d="M10 0 V20" stroke="#E8E2DB" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="390" height="844" fill="#F5F0EB" />
        <rect width="390" height="844" fill="url(#smallGrid)" />
        <rect width="390" height="844" fill="url(#streets)" />

        {/* Main boulevard — diagonal */}
        <path d="M50 200 Q195 400 340 650" stroke="#D6CFC6" strokeWidth="8" strokeLinecap="round" fill="none" />
        <path d="M50 200 Q195 400 340 650" stroke="#E8E2DB" strokeWidth="4" strokeLinecap="round" fill="none" />

        {/* Secondary road — horizontal */}
        <path d="M0 380 H390" stroke="#D6CFC6" strokeWidth="6" fill="none" />
        <path d="M0 380 H390" stroke="#E8E2DB" strokeWidth="3" fill="none" />

        {/* Another avenue */}
        <path d="M160 0 V844" stroke="#D6CFC6" strokeWidth="5" fill="none" />
        <path d="M160 0 V844" stroke="#E8E2DB" strokeWidth="2.5" fill="none" />

        {/* Small cross street */}
        <path d="M0 550 H390" stroke="#DDD6CD" strokeWidth="4" fill="none" />

        {/* Park / green area */}
        <rect x="200" y="280" width="100" height="80" rx="12" fill="#E6E0D5" opacity="0.7" />
        <circle cx="225" cy="310" r="8" fill="#D1CCC4" opacity="0.5" />
        <circle cx="260" cy="325" r="6" fill="#D1CCC4" opacity="0.5" />
        <circle cx="280" cy="300" r="10" fill="#D1CCC4" opacity="0.5" />

        {/* Building blocks */}
        <rect x="40" y="120" width="70" height="50" rx="6" fill="#EAE4DD" />
        <rect x="260" y="440" width="80" height="60" rx="6" fill="#EAE4DD" />
        <rect x="60" y="460" width="60" height="70" rx="6" fill="#EAE4DD" />
        <rect x="80" y="260" width="50" height="40" rx="6" fill="#EAE4DD" />
        <rect x="280" y="160" width="65" height="45" rx="6" fill="#EAE4DD" />

        {/* Metro marker */}
        <circle cx="160" cy="380" r="10" fill="#E0D9D1" stroke="#D6CFC6" strokeWidth="1.5" />
        <text x="160" y="384" textAnchor="middle" fontSize="9" fill="#6B6878" fontWeight="600">M</text>

        {/* Street labels */}
        <text x="170" y="170" fontSize="8" fill="#A39E96" fontWeight="400" transform="rotate(-25, 170, 170)">Rue de Vaugirard</text>
        <text x="240" y="395" fontSize="8" fill="#A39E96" fontWeight="400">Bd de Grenelle</text>
        <text x="165" y="560" fontSize="7" fill="#A39E96" fontWeight="400">Rue Linois</text>
      </svg>

      {/* Incident Pins */}
      <IncidentPin
        icon={<AlertTriangle className="h-3.5 w-3.5 text-[var(--color-amber)]" />}
        label="Harcelement"
        type="harassment"
        style={{ top: 220, left: 100 }}
      />
      <IncidentPin
        icon={<ShieldAlert className="h-3.5 w-3.5 text-[var(--color-danger)]" />}
        label="Agression"
        type="assault"
        style={{ top: 360, left: 240 }}
      />
      <IncidentPin
        icon={<Eye className="h-3.5 w-3.5 text-[var(--color-gold)]" />}
        label="Suspect"
        type="theft"
        style={{ top: 430, left: 140 }}
      />

      {/* User location */}
      <UserDot style={{ top: 340, left: 175 }} />
    </div>
  )
}
