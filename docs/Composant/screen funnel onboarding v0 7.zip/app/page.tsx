"use client"

import { useState } from "react"
import { PermissionLocation } from "@/components/breveil/permission-location"
import { PermissionNotifications } from "@/components/breveil/permission-notifications"
import { AddCircle } from "@/components/breveil/add-circle"
import { Welcome } from "@/components/breveil/welcome"
import { SosCountdown } from "@/components/breveil/sos-countdown"
import { SosAlertSheet } from "@/components/breveil/sos-alert-sheet"
import { Profile } from "@/components/breveil/profile"

const TABS = [
  { id: "location", label: "Localisation" },
  { id: "notifications", label: "Notifications" },
  { id: "circle", label: "Cercle" },
  { id: "welcome", label: "Bienvenue" },
  { id: "sos", label: "SOS" },
  { id: "alert", label: "Alerte" },
  { id: "profile", label: "Profil" },
] as const

type TabId = (typeof TABS)[number]["id"]

function ScreenContent({ tab }: { tab: TabId }) {
  switch (tab) {
    case "location":
      return <PermissionLocation />
    case "notifications":
      return <PermissionNotifications />
    case "circle":
      return <AddCircle />
    case "welcome":
      return <Welcome name="Camille" />
    case "sos":
      return <SosCountdown />
    case "alert":
      return <SosAlertSheet />
    case "profile":
      return <Profile />
  }
}

export default function Page() {
  const [activeTab, setActiveTab] = useState<TabId>("profile")

  return (
    <div className="flex min-h-dvh flex-col items-center bg-background">
      {/* Tab switcher */}
      <div
        className="flex w-full justify-center gap-1 px-4 pt-4 pb-3"
        style={{ maxWidth: 375 }}
      >
        {TABS.map((tab) => {
          const isActive = activeTab === tab.id
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className="flex-1 rounded-[10px] py-2 text-[11px] font-medium transition-all duration-200"
              style={{
                backgroundColor: isActive
                  ? "rgba(232,168,56,0.12)"
                  : "rgba(255,255,255,0.04)",
                color: isActive ? "#E8A838" : "rgba(255,255,255,0.35)",
                border: `1px solid ${isActive ? "rgba(232,168,56,0.25)" : "rgba(255,255,255,0.06)"}`,
              }}
            >
              {tab.label}
            </button>
          )
        })}
      </div>

      {/* Screen */}
      <main
        className="relative mx-auto flex flex-1 flex-col bg-background"
        style={{ maxWidth: 375, width: "100%" }}
      >
        <ScreenContent tab={activeTab} />
      </main>
    </div>
  )
}
